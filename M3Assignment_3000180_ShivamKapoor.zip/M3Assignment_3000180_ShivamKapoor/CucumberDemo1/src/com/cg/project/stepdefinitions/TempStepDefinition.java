package com.cg.project.stepdefinitions;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;;
public class TempStepDefinition {


	@Given("^user is able to access 'www\\.google\\.in' on browser$")
	public void user_is_able_to_access_www_google_in_on_browser() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^user enter 'Agile Methodology' in search box$")
	public void user_enter_Agile_Methodology_in_search_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^all links with 'Agile Methodology' should display$")
	public void all_links_with_Agile_Methodology_should_display() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}
}
